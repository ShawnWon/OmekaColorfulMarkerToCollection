<?php

class Ghost_Service_ReCaptcha2_Exception extends Ghost_Service_Exception {
  
}
